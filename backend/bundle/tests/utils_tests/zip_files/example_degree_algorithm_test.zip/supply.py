from bundle.GraphObjects.Graph import Graph
import os


with open(os.path.dirname(os.path.realpath(__file__)) + '/graph.json', 'r') as graph_json_file:
    graph_json = graph_json_file.read()

graph_obj: Graph = Graph.graph_generator(graph_json)
