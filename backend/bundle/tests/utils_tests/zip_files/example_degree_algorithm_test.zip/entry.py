from supply import graph_obj as graph
from bundle.seeker import tracer


@tracer('edge', 'node', 'degree_dict')
def graphery_count_degree_by_edges() -> None:
    degree_dict = {}

    for edge in graph.edges:
        for node in edge:
            if node in degree_dict:
                degree_dict[node] += 1
            else: 
                degree_dict[node] = 1
