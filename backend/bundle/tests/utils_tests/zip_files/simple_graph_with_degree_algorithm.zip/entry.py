from supply import graph_obj as graph
from bundle.seeker import tracer
from collections import OrderedDict


@tracer('node', 'node_degree', 'edge')
def graphery_count_degree_by_nodes() -> dict:
    degree_dict = {}
    # loop through nodes version
    for node in graph.nodes:
        node_degree = 0
        for edge in graph.edges:
            if node in edge:
                node_degree += 1
        degree_dict[node] = node_degree

    return OrderedDict(sorted(degree_dict.items()))
        

@tracer('edge', 'node')
def graphery_count_degree_by_edges() -> dict:
    degree_dict = {}

    for edge in graph.edges:
        for node in edge:
            if node in degree_dict:
                degree_dict[node] += 1
            else: 
                degree_dict[node] = 1

    return OrderedDict(sorted(degree_dict.items()))


expected_dict = 'OrderedDict([(Node(id: n0), 1), (Node(id: n1), 3), (Node(id: n10), 1), (Node(id: n11), 2), ' \
                '(Node(id: n12), 2), (Node(id: n13), 3), (Node(id: n14), 1), (Node(id: n15), 1), (Node(id: n16), 1), ' \
                '(Node(id: n2), 3), (Node(id: n3), 3), (Node(id: n4), 3), (Node(id: n5), 1), (Node(id: n6), 2), ' \
                '(Node(id: n7), 1), (Node(id: n8), 3), (Node(id: n9), 1)]) '
