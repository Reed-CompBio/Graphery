from bundle.utils.cache_file_helpers import get_md5_of_a_string 
content = 'These violent delights have violent ends'
md5_content = get_md5_of_a_string(content)
    
