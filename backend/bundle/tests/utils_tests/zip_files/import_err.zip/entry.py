print('start importing')

import bundle.err 

print('end importing')