from bundle.GraphObjects.Node import Node
from bundle.GraphObjects.Edge import Edge


node_id_list = [1, 2, 5, 7, 11]
node_list = []

for node_id in node_id_list:
    node_list.append(Node(node_id))

edge_id_list = [(1, (node_list[1], node_list[3])), 
                (2, (node_list[0], node_list[2])), 
                (3, (node_list[3], node_list[4])),
                (4, (node_list[1], node_list[2])), 
                (5, (node_list[2], node_list[3])), 
                (6, (node_list[1], node_list[4]))]
edge_list = []

for edge_id, node_pair in edge_id_list:
    edge_list.append(Edge(edge_id, node_pair))
