from bundle.GraphObjects.Graph import Graph
import os


with open(os.path.dirname(os.path.realpath(__file__)) + '/graph.json', 'r') as json_file:
    json_string = json_file.read()

graph = Graph.graph_generator(json_string)
