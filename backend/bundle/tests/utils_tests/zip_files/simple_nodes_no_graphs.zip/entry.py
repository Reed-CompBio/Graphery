from bundle.GraphObjects.Node import Node


node_id_list = [1, 2, 5, 7, 11]
node_list = []

for node_id in node_id_list:
    node_list.append(Node(node_id))

